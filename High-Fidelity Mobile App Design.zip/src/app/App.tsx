import { useState } from 'react';
import { Moon, Sun } from 'lucide-react';
import { HomeScreen } from './components/HomeScreen';
import { DineScreen } from './components/DineScreen';
import { SafeExitScreen } from './components/SafeExitScreen';
import { MomentsScreen } from './components/MomentsScreen';
import { BottomNavigation } from './components/BottomNavigation';

export default function App() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [activeScreen, setActiveScreen] = useState('home');

  const isDark = theme === 'dark';

  const handleNavigate = (screen: string) => {
    setActiveScreen(screen);
  };

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  return (
    <div
      className="relative w-full h-screen overflow-hidden transition-colors duration-500"
      style={{
        background: isDark ? '#000000' : '#F8F9FA',
        color: isDark ? '#FFFFFF' : '#000000',
        maxWidth: '430px',
        margin: '0 auto',
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif"
      }}
    >
      {/* Theme Toggle Button */}
      <button
        onClick={toggleTheme}
        className="fixed top-6 right-6 z-50 p-3 transition-all duration-300"
        style={{
          background: isDark
            ? 'rgba(255,255,255,0.1)'
            : 'rgba(0,0,0,0.08)',
          borderRadius: '16px',
          border: `1px solid ${isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.1)'}`,
          backdropFilter: 'blur(10px)',
          WebkitBackdropFilter: 'blur(10px)',
          boxShadow: '0 4px 16px rgba(0, 0, 0, 0.1)'
        }}
      >
        {isDark ? (
          <Sun size={20} style={{ color: '#FFD700' }} />
        ) : (
          <Moon size={20} style={{ color: '#8B5CF6' }} />
        )}
      </button>

      {/* Screen Router */}
      <div className="h-full">
        {activeScreen === 'home' && (
          <HomeScreen
            theme={theme}
            onNavigate={handleNavigate}
            activeTab={activeScreen}
          />
        )}

        {activeScreen === 'dine' && (
          <DineScreen
            theme={theme}
            onBack={() => handleNavigate('home')}
          />
        )}

        {activeScreen === 'safe-exit' && (
          <SafeExitScreen
            theme={theme}
            onBack={() => handleNavigate('home')}
          />
        )}

        {activeScreen === 'moments' && (
          <MomentsScreen
            theme={theme}
            onBack={() => handleNavigate('home')}
          />
        )}

        {activeScreen === 'working' && (
          <div className="flex items-center justify-center h-full">
            <div className="text-center px-6">
              <div
                className="w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-4 text-4xl"
                style={{
                  background: isDark
                    ? 'rgba(139, 92, 246, 0.1)'
                    : 'rgba(139, 92, 246, 0.08)',
                  border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.3)' : 'rgba(139, 92, 246, 0.2)'}`
                }}
              >
                💼
              </div>
              <h3 className="mb-2" style={{ fontSize: '20px' }}>Working</h3>
              <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                Скоро буде доступно
              </p>
            </div>
          </div>
        )}

        {activeScreen === 'living' && (
          <div className="flex items-center justify-center h-full">
            <div className="text-center px-6">
              <div
                className="w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-4 text-4xl"
                style={{
                  background: isDark
                    ? 'rgba(139, 92, 246, 0.1)'
                    : 'rgba(139, 92, 246, 0.08)',
                  border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.3)' : 'rgba(139, 92, 246, 0.2)'}`
                }}
              >
                🏢
              </div>
              <h3 className="mb-2" style={{ fontSize: '20px' }}>Living</h3>
              <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                Скоро буде доступно
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation
        theme={theme}
        activeScreen={activeScreen}
        onNavigate={handleNavigate}
      />
    </div>
  );
}
