import { useState } from 'react';
import { ArrowLeft, Users, Clock } from 'lucide-react';

interface DineScreenProps {
  theme: 'dark' | 'light';
  onBack: () => void;
}

interface Table {
  id: number;
  x: number;
  y: number;
  seats: number;
  occupied: boolean;
}

export function DineScreen({ theme, onBack }: DineScreenProps) {
  const isDark = theme === 'dark';
  const [selectedTable, setSelectedTable] = useState<number | null>(null);

  const tables: Table[] = [
    { id: 1, x: 20, y: 20, seats: 2, occupied: false },
    { id: 2, x: 45, y: 20, seats: 4, occupied: true },
    { id: 3, x: 70, y: 20, seats: 2, occupied: false },
    { id: 4, x: 20, y: 45, seats: 6, occupied: false },
    { id: 5, x: 45, y: 45, seats: 4, occupied: false },
    { id: 6, x: 70, y: 45, seats: 4, occupied: true },
    { id: 7, x: 20, y: 70, seats: 2, occupied: false },
    { id: 8, x: 45, y: 70, seats: 4, occupied: false },
    { id: 9, x: 70, y: 70, seats: 6, occupied: false }
  ];

  const selectedTableData = tables.find(t => t.id === selectedTable);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div
        className="px-6 pt-14 pb-6"
        style={{
          background: isDark
            ? 'linear-gradient(180deg, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.7) 100%)'
            : 'linear-gradient(180deg, rgba(248,249,250,0.95) 0%, rgba(248,249,250,0.7) 100%)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)'
        }}
      >
        <div className="flex items-center mb-6">
          <button onClick={onBack} className="mr-4 p-2 -ml-2">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h2 style={{ fontSize: '24px' }}>Ресторан "Київ"</h2>
            <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Оберіть стіл
            </p>
          </div>
        </div>

        <div className="flex gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div
              className="w-3 h-3 rounded-full"
              style={{ background: '#8B5CF6' }}
            />
            <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>Вільний</span>
          </div>
          <div className="flex items-center gap-2">
            <div
              className="w-3 h-3 rounded-full"
              style={{ background: isDark ? '#444' : '#ccc' }}
            />
            <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>Зайнятий</span>
          </div>
        </div>
      </div>

      {/* Floor Plan */}
      <div className="flex-1 px-6 py-8 overflow-y-auto">
        <div
          className="relative w-full aspect-square max-w-md mx-auto p-6"
          style={{
            background: isDark
              ? 'linear-gradient(135deg, rgba(139, 92, 246, 0.05) 0%, rgba(0,0,0,0.2) 100%)'
              : 'linear-gradient(135deg, rgba(139, 92, 246, 0.03) 0%, rgba(255,255,255,0.5) 100%)',
            borderRadius: '32px',
            border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.2)' : 'rgba(139, 92, 246, 0.15)'}`,
            boxShadow: '0 8px 32px rgba(139, 92, 246, 0.1)'
          }}
        >
          {/* Grid lines */}
          <div className="absolute inset-0 opacity-10">
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="table-grid" width="30" height="30" patternUnits="userSpaceOnUse">
                  <path d="M 30 0 L 0 0 0 30" fill="none" stroke={isDark ? '#8B5CF6' : '#666'} strokeWidth="0.5"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#table-grid)" />
            </svg>
          </div>

          {/* Tables */}
          {tables.map((table) => (
            <button
              key={table.id}
              onClick={() => !table.occupied && setSelectedTable(table.id)}
              disabled={table.occupied}
              className="absolute transition-all duration-300"
              style={{
                left: `${table.x}%`,
                top: `${table.y}%`,
                transform: 'translate(-50%, -50%)',
                width: '70px',
                height: '70px'
              }}
            >
              <div
                className="w-full h-full rounded-full flex items-center justify-center relative"
                style={{
                  background: table.occupied
                    ? (isDark ? 'rgba(100,100,100,0.3)' : 'rgba(200,200,200,0.5)')
                    : selectedTable === table.id
                      ? 'rgba(139, 92, 246, 0.3)'
                      : isDark
                        ? 'rgba(139, 92, 246, 0.1)'
                        : 'rgba(139, 92, 246, 0.08)',
                  border: table.occupied
                    ? `2px solid ${isDark ? '#666' : '#ccc'}`
                    : selectedTable === table.id
                      ? '3px solid #8B5CF6'
                      : `2px solid ${isDark ? 'rgba(139, 92, 246, 0.3)' : 'rgba(139, 92, 246, 0.2)'}`,
                  boxShadow: selectedTable === table.id
                    ? '0 0 20px rgba(139, 92, 246, 0.4), 0 0 40px rgba(139, 92, 246, 0.2)'
                    : table.occupied
                      ? 'none'
                      : '0 4px 12px rgba(139, 92, 246, 0.1)',
                  cursor: table.occupied ? 'not-allowed' : 'pointer',
                  opacity: table.occupied ? 0.5 : 1
                }}
              >
                <div className="text-center">
                  <div
                    className="mb-1"
                    style={{
                      fontSize: '16px',
                      color: selectedTable === table.id ? '#8B5CF6' : 'inherit'
                    }}
                  >
                    {table.id}
                  </div>
                  <div
                    className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-600'}`}
                  >
                    {table.seats}
                  </div>
                </div>
              </div>

              {/* Selection pulse animation */}
              {selectedTable === table.id && (
                <div
                  className="absolute inset-0 rounded-full animate-ping"
                  style={{
                    background: 'rgba(139, 92, 246, 0.4)',
                    animationDuration: '2s'
                  }}
                />
              )}
            </button>
          ))}
        </div>

        {/* Legend */}
        <div className="mt-6 text-center">
          <p className={`text-sm ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
            Натисніть на стіл для бронювання
          </p>
        </div>
      </div>

      {/* Floating Bottom Sheet */}
      {selectedTable && selectedTableData && (
        <div
          className="fixed bottom-0 left-0 right-0 p-6 pb-32 animate-slide-up"
          style={{
            background: isDark
              ? 'linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.95) 20%, rgba(0,0,0,0.98) 100%)'
              : 'linear-gradient(180deg, transparent 0%, rgba(248,249,250,0.95) 20%, rgba(248,249,250,0.98) 100%)',
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)'
          }}
        >
          <div
            className="p-6 mb-4"
            style={{
              background: isDark
                ? 'linear-gradient(135deg, rgba(139, 92, 246, 0.15) 0%, rgba(139, 92, 246, 0.05) 100%)'
                : 'linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(139, 92, 246, 0.03) 100%)',
              borderRadius: '28px',
              border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.3)' : 'rgba(139, 92, 246, 0.2)'}`,
              boxShadow: '0 8px 32px rgba(139, 92, 246, 0.15)'
            }}
          >
            <h3 className="mb-4" style={{ fontSize: '20px' }}>
              Стіл №{selectedTableData.id}
            </h3>

            <div className="flex gap-4 mb-4">
              <div className="flex items-center gap-2">
                <Users size={18} style={{ color: '#8B5CF6' }} />
                <span className="text-sm">{selectedTableData.seats} особи</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock size={18} style={{ color: '#8B5CF6' }} />
                <span className="text-sm">Зараз</span>
              </div>
            </div>
          </div>

          <button
            className="w-full py-4 transition-all duration-300"
            style={{
              background: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)',
              borderRadius: '28px',
              boxShadow: '0 8px 24px rgba(139, 92, 246, 0.3), 0 0 40px rgba(139, 92, 246, 0.1)',
              color: 'white',
              fontSize: '16px'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.boxShadow = '0 12px 32px rgba(139, 92, 246, 0.4), 0 0 50px rgba(139, 92, 246, 0.2)';
              e.currentTarget.style.transform = 'translateY(-2px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.boxShadow = '0 8px 24px rgba(139, 92, 246, 0.3), 0 0 40px rgba(139, 92, 246, 0.1)';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            Забронювати
          </button>
        </div>
      )}

      <style>{`
        @keyframes slide-up {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        .animate-slide-up {
          animation: slide-up 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
