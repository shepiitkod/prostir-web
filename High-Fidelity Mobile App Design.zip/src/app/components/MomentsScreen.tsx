import { ArrowLeft, ShieldCheck, MapPin } from 'lucide-react';

interface MomentsScreenProps {
  theme: 'dark' | 'light';
  onBack: () => void;
}

interface Profile {
  id: number;
  name: string;
  avatar: string;
  verified: boolean;
  location: string;
  mutual: number;
}

export function MomentsScreen({ theme, onBack }: MomentsScreenProps) {
  const isDark = theme === 'dark';

  const profiles: Profile[] = [
    { id: 1, name: 'Олена К.', avatar: '👩‍💼', verified: true, location: 'Ресторан "Київ"', mutual: 3 },
    { id: 2, name: 'Ігор М.', avatar: '👨‍💻', verified: true, location: 'Ресторан "Київ"', mutual: 5 },
    { id: 3, name: 'Марія С.', avatar: '👩‍🎨', verified: true, location: 'Коворкінг "Hub"', mutual: 2 },
    { id: 4, name: 'Андрій В.', avatar: '👨‍🔬', verified: true, location: 'Ресторан "Київ"', mutual: 7 },
    { id: 5, name: 'Софія Л.', avatar: '👩‍🚀', verified: true, location: 'Кафе "Aroma"', mutual: 4 },
    { id: 6, name: 'Максим Р.', avatar: '👨‍🎨', verified: true, location: 'Коворкінг "Hub"', mutual: 1 }
  ];

  const sameLocationProfiles = profiles.filter(p => p.location === 'Ресторан "Київ"');

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div
        className="px-6 pt-14 pb-6"
        style={{
          background: isDark
            ? 'linear-gradient(180deg, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.7) 100%)'
            : 'linear-gradient(180deg, rgba(248,249,250,0.95) 0%, rgba(248,249,250,0.7) 100%)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)'
        }}
      >
        <div className="flex items-center mb-6">
          <button onClick={onBack} className="mr-4 p-2 -ml-2">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h2 style={{ fontSize: '24px' }}>Moments</h2>
            <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Поруч зараз
            </p>
          </div>
        </div>

        {/* Location Filter */}
        <div
          className="px-4 py-3 flex items-center gap-3"
          style={{
            background: isDark
              ? 'rgba(139, 92, 246, 0.1)'
              : 'rgba(139, 92, 246, 0.08)',
            borderRadius: '20px',
            border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.2)' : 'rgba(139, 92, 246, 0.15)'}`
          }}
        >
          <MapPin size={18} style={{ color: '#8B5CF6' }} />
          <span className="text-sm">Ресторан "Київ"</span>
          <div
            className="ml-auto w-6 h-6 rounded-full flex items-center justify-center text-xs"
            style={{
              background: '#8B5CF6',
              color: 'white',
              fontSize: '11px'
            }}
          >
            {sameLocationProfiles.length}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 px-6 py-6 overflow-y-auto">
        {/* Connection Network Visualization */}
        <div
          className="relative mb-8 p-6"
          style={{
            background: isDark
              ? 'linear-gradient(135deg, rgba(139, 92, 246, 0.08) 0%, rgba(0,0,0,0.2) 100%)'
              : 'linear-gradient(135deg, rgba(139, 92, 246, 0.05) 0%, rgba(255,255,255,0.5) 100%)',
            borderRadius: '32px',
            border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.2)' : 'rgba(139, 92, 246, 0.15)'}`,
            minHeight: '160px',
            boxShadow: '0 8px 32px rgba(139, 92, 246, 0.1)'
          }}
        >
          <svg className="absolute inset-0 w-full h-full" style={{ borderRadius: '32px' }}>
            <defs>
              <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="rgba(139, 92, 246, 0.1)" />
                <stop offset="100%" stopColor="rgba(139, 92, 246, 0.3)" />
              </linearGradient>
            </defs>
            {/* Connection lines between same location users */}
            <line x1="30%" y1="40%" x2="50%" y2="60%" stroke="url(#lineGradient)" strokeWidth="2" strokeDasharray="4,4" />
            <line x1="50%" y1="60%" x2="70%" y2="40%" stroke="url(#lineGradient)" strokeWidth="2" strokeDasharray="4,4" />
            <line x1="30%" y1="40%" x2="70%" y2="40%" stroke="url(#lineGradient)" strokeWidth="1" strokeDasharray="4,4" />
          </svg>

          <div className="relative z-10 text-center pt-12">
            <p style={{ fontSize: '32px' }}>{sameLocationProfiles.length}</p>
            <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              людей зараз у вашій локації
            </p>
          </div>
        </div>

        {/* Profile Grid */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {profiles.map((profile, index) => {
            const isSameLocation = profile.location === 'Ресторан "Київ"';

            return (
              <button
                key={profile.id}
                className="relative p-6 text-left transition-all duration-300"
                style={{
                  background: isDark
                    ? isSameLocation
                      ? 'linear-gradient(135deg, rgba(139, 92, 246, 0.15) 0%, rgba(139, 92, 246, 0.05) 100%)'
                      : 'rgba(255,255,255,0.03)'
                    : isSameLocation
                      ? 'linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(139, 92, 246, 0.03) 100%)'
                      : 'rgba(0,0,0,0.02)',
                  borderRadius: '28px',
                  border: `1px solid ${
                    isSameLocation
                      ? isDark ? 'rgba(139, 92, 246, 0.3)' : 'rgba(139, 92, 246, 0.2)'
                      : isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)'
                  }`,
                  boxShadow: isSameLocation
                    ? '0 4px 16px rgba(139, 92, 246, 0.15)'
                    : '0 4px 16px rgba(0, 0, 0, 0.02)'
                }}
              >
                {/* Connection indicator for same location */}
                {isSameLocation && (
                  <div
                    className="absolute -top-1 -right-1 w-3 h-3 rounded-full animate-pulse"
                    style={{
                      background: '#8B5CF6',
                      boxShadow: '0 0 10px rgba(139, 92, 246, 0.8)',
                      animationDuration: '2s'
                    }}
                  />
                )}

                {/* Avatar */}
                <div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center mb-3 text-3xl"
                  style={{
                    background: isDark
                      ? 'rgba(0,0,0,0.3)'
                      : 'rgba(255,255,255,0.8)',
                    border: `2px solid ${
                      isSameLocation
                        ? '#8B5CF6'
                        : isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.08)'
                    }`
                  }}
                >
                  {profile.avatar}
                </div>

                {/* Name with verification badge */}
                <div className="flex items-center gap-2 mb-2">
                  <h4 style={{ fontSize: '14px' }}>{profile.name}</h4>
                  {profile.verified && (
                    <ShieldCheck
                      size={16}
                      style={{
                        color: '#8B5CF6',
                        filter: 'drop-shadow(0 0 4px rgba(139, 92, 246, 0.6))'
                      }}
                    />
                  )}
                </div>

                {/* Location */}
                <p
                  className={`text-xs mb-2 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}
                  style={{
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap'
                  }}
                >
                  {profile.location}
                </p>

                {/* Mutual connections */}
                <div className="flex items-center gap-1">
                  <div
                    className="w-4 h-4 rounded-full flex items-center justify-center"
                    style={{
                      background: isDark
                        ? 'rgba(139, 92, 246, 0.2)'
                        : 'rgba(139, 92, 246, 0.15)',
                      fontSize: '9px'
                    }}
                  >
                    {profile.mutual}
                  </div>
                  <span
                    className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-600'}`}
                  >
                    спільних
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Info Banner */}
        <div
          className="p-6 mb-24"
          style={{
            background: isDark
              ? 'linear-gradient(135deg, rgba(139, 92, 246, 0.08) 0%, rgba(0,0,0,0.2) 100%)'
              : 'linear-gradient(135deg, rgba(139, 92, 246, 0.05) 0%, rgba(255,255,255,0.5) 100%)',
            borderRadius: '28px',
            border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.2)' : 'rgba(139, 92, 246, 0.15)'}`
          }}
        >
          <div className="flex items-start gap-3">
            <ShieldCheck size={20} style={{ color: '#8B5CF6', marginTop: '2px' }} />
            <div>
              <h4 className="mb-1" style={{ fontSize: '14px' }}>
                Перевірені профілі
              </h4>
              <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                Всі користувачі підтверджені через Дія. Ваші дані захищені.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
