import { ArrowLeft, MapPin, CheckCircle2 } from 'lucide-react';

interface SafeExitScreenProps {
  theme: 'dark' | 'light';
  onBack: () => void;
}

export function SafeExitScreen({ theme, onBack }: SafeExitScreenProps) {
  const isDark = theme === 'dark';

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div
        className="px-6 pt-14 pb-6"
        style={{
          background: isDark
            ? 'linear-gradient(180deg, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.7) 100%)'
            : 'linear-gradient(180deg, rgba(248,249,250,0.95) 0%, rgba(248,249,250,0.7) 100%)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)'
        }}
      >
        <div className="flex items-center">
          <button onClick={onBack} className="mr-4 p-2 -ml-2">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h2 style={{ fontSize: '24px' }}>Safe Exit</h2>
            <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Автоматичний розрахунок
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 px-6 py-8 overflow-y-auto">
        {/* Geofencing Map Visualization */}
        <div
          className="relative w-full aspect-square mb-6 overflow-hidden"
          style={{
            background: isDark
              ? 'linear-gradient(135deg, rgba(139, 92, 246, 0.08) 0%, rgba(0,0,0,0.3) 100%)'
              : 'linear-gradient(135deg, rgba(139, 92, 246, 0.05) 0%, rgba(230,230,235,0.8) 100%)',
            borderRadius: '32px',
            border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.2)' : 'rgba(139, 92, 246, 0.15)'}`,
            boxShadow: '0 8px 32px rgba(139, 92, 246, 0.1)'
          }}
        >
          {/* Simplified Map Background */}
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: isDark
                ? 'linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)'
                : 'linear-gradient(rgba(0,0,0,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.03) 1px, transparent 1px)',
              backgroundSize: '20px 20px'
            }}
          />

          {/* Geofence Radius - Outer pulse */}
          <div
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full animate-pulse"
            style={{
              width: '280px',
              height: '280px',
              background: 'radial-gradient(circle, rgba(139, 92, 246, 0.15) 0%, rgba(139, 92, 246, 0.05) 50%, transparent 100%)',
              border: '2px dashed rgba(139, 92, 246, 0.3)',
              animationDuration: '3s'
            }}
          />

          {/* Geofence Radius - Middle */}
          <div
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full"
            style={{
              width: '200px',
              height: '200px',
              background: 'radial-gradient(circle, rgba(139, 92, 246, 0.2) 0%, rgba(139, 92, 246, 0.08) 70%, transparent 100%)',
              border: '2px solid rgba(139, 92, 246, 0.4)'
            }}
          />

          {/* Restaurant Building Icon */}
          <div
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center"
            style={{
              width: '60px',
              height: '60px',
              background: isDark ? 'rgba(0,0,0,0.7)' : 'rgba(255,255,255,0.9)',
              borderRadius: '20px',
              border: '2px solid #8B5CF6',
              boxShadow: '0 4px 24px rgba(139, 92, 246, 0.4)'
            }}
          >
            <div className="text-center">
              <div style={{ fontSize: '24px' }}>🏢</div>
            </div>
          </div>

          {/* User Location Indicator */}
          <div
            className="absolute left-1/4 top-1/3 -translate-x-1/2 -translate-y-1/2"
            style={{
              width: '40px',
              height: '40px'
            }}
          >
            <div
              className="w-full h-full rounded-full flex items-center justify-center relative"
              style={{
                background: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)',
                boxShadow: '0 0 20px rgba(139, 92, 246, 0.6), 0 4px 12px rgba(139, 92, 246, 0.4)'
              }}
            >
              <MapPin size={24} color="white" />
            </div>

            {/* Pulse animation for user location */}
            <div
              className="absolute inset-0 rounded-full animate-ping"
              style={{
                background: 'rgba(139, 92, 246, 0.4)',
                animationDuration: '2s'
              }}
            />
          </div>

          {/* Distance indicator */}
          <div
            className="absolute bottom-4 right-4 px-4 py-2"
            style={{
              background: isDark ? 'rgba(0,0,0,0.7)' : 'rgba(255,255,255,0.9)',
              borderRadius: '16px',
              backdropFilter: 'blur(10px)',
              WebkitBackdropFilter: 'blur(10px)',
              border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.3)' : 'rgba(139, 92, 246, 0.2)'}`,
              boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
            }}
          >
            <p className="text-xs" style={{ color: '#8B5CF6' }}>
              45м від закладу
            </p>
          </div>
        </div>

        {/* Info Card */}
        <div
          className="p-6 mb-6"
          style={{
            background: isDark
              ? 'linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(139, 92, 246, 0.05) 100%)'
              : 'linear-gradient(135deg, rgba(139, 92, 246, 0.08) 0%, rgba(139, 92, 246, 0.03) 100%)',
            borderRadius: '28px',
            border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.2)' : 'rgba(139, 92, 246, 0.15)'}`,
            boxShadow: '0 8px 32px rgba(139, 92, 246, 0.1)'
          }}
        >
          <div className="flex items-start gap-4 mb-4">
            <div
              className="p-3 rounded-2xl"
              style={{
                background: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)',
                boxShadow: '0 4px 16px rgba(139, 92, 246, 0.3)'
              }}
            >
              <CheckCircle2 size={28} color="white" />
            </div>
            <div className="flex-1">
              <h3 className="mb-2" style={{ fontSize: '18px' }}>
                Геозона активна
              </h3>
              <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                Коли ви залишите зону закладу, рахунок буде автоматично закрито
              </p>
            </div>
          </div>

          <div
            className="p-4 rounded-2xl"
            style={{
              background: isDark ? 'rgba(0,0,0,0.3)' : 'rgba(255,255,255,0.5)',
              border: `1px solid ${isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.05)'}`
            }}
          >
            <p className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
              Радіус геозони
            </p>
            <p style={{ fontSize: '16px' }}>100 метрів</p>
          </div>
        </div>

        {/* Digital Receipt Card */}
        <div
          className="p-8"
          style={{
            background: isDark
              ? 'linear-gradient(135deg, rgba(0,0,0,0.5) 0%, rgba(0,0,0,0.3) 100%)'
              : 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0.6) 100%)',
            borderRadius: '32px',
            border: `1px solid ${isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.08)'}`,
            boxShadow: '0 8px 32px rgba(0,0,0,0.1)'
          }}
        >
          <div className="flex items-center justify-between mb-6">
            <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Цифровий чек
            </span>
            <div
              className="w-2 h-2 rounded-full"
              style={{
                background: '#10B981',
                boxShadow: '0 0 10px rgba(16, 185, 129, 0.8)'
              }}
            />
          </div>

          <h3 className="mb-2" style={{ fontSize: '20px' }}>Ресторан "Київ"</h3>
          <p className={`text-sm mb-6 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Стіл №5 • 30 березня, 2026 • 20:15
          </p>

          <div className="space-y-3 mb-6">
            <div className="flex justify-between text-sm">
              <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                Піца Маргарита
              </span>
              <span>140 UAH</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                Цезар з куркою
              </span>
              <span>85 UAH</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                Лимонад
              </span>
              <span>15 UAH</span>
            </div>
          </div>

          <div
            className="pt-6 mb-6"
            style={{
              borderTop: `1px dashed ${isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)'}`
            }}
          >
            <div className="flex justify-between mb-2">
              <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                Сума
              </span>
              <span className="text-sm">240 UAH</span>
            </div>
            <div className="flex justify-between">
              <span>Всього</span>
              <span style={{ fontSize: '24px' }}>240 UAH</span>
            </div>
          </div>

          <div
            className="p-4 text-center rounded-2xl"
            style={{
              background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.15) 0%, rgba(139, 92, 246, 0.05) 100%)',
              border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.3)' : 'rgba(139, 92, 246, 0.2)'}`,
              color: '#8B5CF6'
            }}
          >
            <p className="text-sm">
              Рахунок буде закрито автоматично
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
