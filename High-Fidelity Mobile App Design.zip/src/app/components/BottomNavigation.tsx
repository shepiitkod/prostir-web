import { Home, Utensils, CreditCard, Sparkles } from 'lucide-react';

interface BottomNavigationProps {
  theme: 'dark' | 'light';
  activeScreen: string;
  onNavigate: (screen: string) => void;
}

export function BottomNavigation({ theme, activeScreen, onNavigate }: BottomNavigationProps) {
  const isDark = theme === 'dark';

  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'dine', label: 'Dine', icon: Utensils },
    { id: 'safe-exit', label: 'Exit', icon: CreditCard },
    { id: 'moments', label: 'Moments', icon: Sparkles }
  ];

  return (
    <div
      className="fixed bottom-0 left-0 right-0 px-6 pb-8 pt-4 safe-area-bottom"
      style={{
        background: isDark
          ? 'linear-gradient(180deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0.95) 30%, rgba(0,0,0,0.98) 100%)'
          : 'linear-gradient(180deg, rgba(248,249,250,0) 0%, rgba(248,249,250,0.95) 30%, rgba(248,249,250,0.98) 100%)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        zIndex: 50
      }}
    >
      <div
        className="flex items-center justify-around px-4 py-3"
        style={{
          background: isDark
            ? 'rgba(20, 20, 20, 0.8)'
            : 'rgba(255, 255, 255, 0.8)',
          borderRadius: '28px',
          border: `1px solid ${isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.08)'}`,
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12)'
        }}
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeScreen === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="relative flex flex-col items-center gap-1 px-4 py-2 transition-all duration-300"
            >
              {/* Active indicator */}
              {isActive && (
                <div
                  className="absolute -top-1 left-1/2 -translate-x-1/2 w-8 h-1 rounded-full"
                  style={{
                    background: 'linear-gradient(90deg, #8B5CF6 0%, #7C3AED 100%)',
                    boxShadow: '0 0 12px rgba(139, 92, 246, 0.6)'
                  }}
                />
              )}

              {/* Icon */}
              <Icon
                size={22}
                style={{
                  color: isActive ? '#8B5CF6' : isDark ? '#888' : '#999',
                  filter: isActive ? 'drop-shadow(0 0 8px rgba(139, 92, 246, 0.4))' : 'none',
                  transition: 'all 0.3s ease'
                }}
              />

              {/* Label */}
              <span
                className="text-xs transition-all duration-300"
                style={{
                  color: isActive ? '#8B5CF6' : isDark ? '#888' : '#999',
                  fontWeight: isActive ? '500' : '400'
                }}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
