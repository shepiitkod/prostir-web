import { Home, Utensils, Briefcase, Building2, Sparkles } from 'lucide-react';

interface HomeScreenProps {
  theme: 'dark' | 'light';
  onNavigate: (screen: string) => void;
  activeTab: string;
}

export function HomeScreen({ theme, onNavigate, activeTab }: HomeScreenProps) {
  const isDark = theme === 'dark';

  const quickAccessTabs = [
    { id: 'dine', label: 'Dine', icon: Utensils },
    { id: 'working', label: 'Working', icon: Briefcase },
    { id: 'living', label: 'Living', icon: Building2 },
    { id: 'moments', label: 'Moments', icon: Sparkles }
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Background Grid Pattern */}
      <div className="fixed inset-0 pointer-events-none opacity-5">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke={isDark ? '#8B5CF6' : '#666'} strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Header with Glassmorphism */}
      <div
        className="relative px-6 pt-14 pb-6"
        style={{
          background: isDark
            ? 'linear-gradient(180deg, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.7) 100%)'
            : 'linear-gradient(180deg, rgba(248,249,250,0.95) 0%, rgba(248,249,250,0.7) 100%)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)'
        }}
      >
        <div className="flex items-center justify-center mb-2">
          <h1 className="tracking-wider" style={{ fontSize: '28px', letterSpacing: '0.1em' }}>
            PR
            <span className="relative inline-block">
              <span
                className="relative z-10"
                style={{
                  color: '#8B5CF6',
                  textShadow: '0 0 20px rgba(139, 92, 246, 0.8), 0 0 40px rgba(139, 92, 246, 0.4)'
                }}
              >
                O
              </span>
            </span>
            STIR
          </h1>
        </div>
        <p className={`text-center text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
          Urban Operating System
        </p>
      </div>

      {/* Main Content */}
      <div className="flex-1 px-6 pt-8 overflow-y-auto">
        {/* Active Session Card */}
        <div
          className="relative mb-8 p-8 overflow-hidden"
          style={{
            background: isDark
              ? 'linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(139, 92, 246, 0.05) 100%)'
              : 'linear-gradient(135deg, rgba(139, 92, 246, 0.08) 0%, rgba(139, 92, 246, 0.03) 100%)',
            backdropFilter: 'blur(10px)',
            WebkitBackdropFilter: 'blur(10px)',
            borderRadius: '32px',
            border: `1px solid ${isDark ? 'rgba(139, 92, 246, 0.2)' : 'rgba(139, 92, 246, 0.15)'}`,
            boxShadow: '0 8px 32px rgba(139, 92, 246, 0.1)'
          }}
        >
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                Поточна сесія
              </span>
              <div
                className="w-2 h-2 rounded-full"
                style={{
                  background: '#8B5CF6',
                  boxShadow: '0 0 10px rgba(139, 92, 246, 0.8)'
                }}
              />
            </div>

            <h2 className="mb-2" style={{ fontSize: '24px' }}>Ресторан "Київ"</h2>
            <p className={`text-sm mb-6 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Стіл №5 • 2 особи • 18:30
            </p>

            <div className="grid grid-cols-2 gap-4">
              <div
                className="p-4 rounded-3xl"
                style={{
                  background: isDark ? 'rgba(0,0,0,0.3)' : 'rgba(255,255,255,0.5)',
                  border: `1px solid ${isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.05)'}`
                }}
              >
                <p className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                  Рахунок
                </p>
                <p style={{ fontSize: '20px' }}>240 UAH</p>
              </div>
              <div
                className="p-4 rounded-3xl"
                style={{
                  background: isDark ? 'rgba(0,0,0,0.3)' : 'rgba(255,255,255,0.5)',
                  border: `1px solid ${isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.05)'}`
                }}
              >
                <p className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                  Час перебування
                </p>
                <p style={{ fontSize: '20px' }}>1г 24хв</p>
              </div>
            </div>
          </div>

          {/* Decorative corner lines */}
          <div
            className="absolute top-0 right-0 w-32 h-32 opacity-20"
            style={{
              background: 'linear-gradient(225deg, rgba(139, 92, 246, 0.3) 0%, transparent 70%)',
              borderTopRightRadius: '32px'
            }}
          />
        </div>

        {/* Quick Access Tabs */}
        <div className="mb-8">
          <h3 className="mb-4 px-1" style={{ fontSize: '16px' }}>Швидкий доступ</h3>
          <div className="grid grid-cols-2 gap-4">
            {quickAccessTabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => onNavigate(tab.id)}
                  className="relative p-6 text-left transition-all duration-300"
                  style={{
                    background: isDark
                      ? 'rgba(255,255,255,0.03)'
                      : 'rgba(0,0,0,0.02)',
                    borderRadius: '28px',
                    border: `1px solid ${isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)'}`,
                    boxShadow: '0 4px 16px rgba(139, 92, 246, 0.05)'
                  }}
                >
                  <Icon
                    className="mb-3"
                    size={24}
                    style={{ color: '#8B5CF6' }}
                  />
                  <p style={{ fontSize: '15px' }}>{tab.label}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="mb-24">
          <h3 className="mb-4 px-1" style={{ fontSize: '16px' }}>Остання активність</h3>
          <div className="space-y-3">
            {[
              { title: 'Ресторан "Київ"', time: '2 години тому', amount: '240 UAH' },
              { title: 'Коворкінг "Hub"', time: 'Вчора, 14:20', amount: '180 UAH' },
              { title: 'Кінотеатр "Multiplex"', time: '3 дні тому', amount: '320 UAH' }
            ].map((activity, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4"
                style={{
                  background: isDark ? 'rgba(255,255,255,0.02)' : 'rgba(0,0,0,0.02)',
                  borderRadius: '24px',
                  border: `1px solid ${isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.04)'}`
                }}
              >
                <div>
                  <p style={{ fontSize: '14px' }}>{activity.title}</p>
                  <p className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                    {activity.time}
                  </p>
                </div>
                <p style={{ fontSize: '14px' }}>{activity.amount}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
